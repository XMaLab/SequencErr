nextseq<-read.table("nextseq_error_rates_all_2_surface.txt",header=TRUE,sep="\t",na.strings=c("NA"))
is.na(nextseq$N1_total)
novaseq<-read.table("novaseq_error_rates_all_2_surface.txt",header=TRUE,sep="\t",na.strings=c("NA"))
hiseq<-read.table("hiseq_error_rates_all_2_surface.txt",header=TRUE,sep="\t",na.strings=c("NA"))

sum_hi<-hiseq[hiseq[,"N1_total"]>1000000 & hiseq[,"N2_total"]>1000000,]
sum_next<-nextseq[nextseq[,"N1_total"]>1000000 & nextseq[,"N2_total"]>1000000,]
sum_nova<-novaseq[novaseq[,"N1_total"]>1000000 & novaseq[,"N2_total"]>1000000,]

rlt<-rbind(sum_hi,sum_next,sum_nova)
colnames(rlt)<-c("platform","instrument","flowcell","N1_mismatch","N1_total","N1_ERPM","N2_mismatch","N2_total","N2_ERPM")
write.table(rlt, "cross_platform_summary_mean_Suface.txt",row.names=F,col.names=TRUE,sep="\t",quote=F)


rlt0<-read.table("cross_platform_summary_mean_Suface.txt",header=TRUE,sep="\t")
outlier_instrument<-c("E00332","NS500183")
outlier_flowcell<-c("C5E39ANXX_nouse")
good<-setdiff(1:nrow(rlt0),which(as.character(rlt0[,"instrument"]) %in% outlier_instrument | as.character(rlt0[,"flowcell"]) %in% outlier_flowcell))
rlt<-rlt0[good,]


platform<-c(paste(as.character(rlt[,"platform"]),"_1",sep=""),paste(as.character(rlt[,"platform"]),"_2",sep=""))
instrument<-c(as.character(rlt[,"instrument"]),as.character(rlt[,"instrument"]))
flowcell<-c(as.character(rlt[,"flowcell"]),as.character(rlt[,"flowcell"]))
ERPM<-c(as.numeric(rlt[,"N1_ERPM"]),as.numeric(rlt[,"N2_ERPM"]))

rlt<-data.frame(platform=as.character(platform),instrument=as.character(instrument),flowcell=as.character(flowcell),ERPM)

hiseq_1<-rlt[rlt$platform=="aHiSeq_1",]
hiseq_2<-rlt[rlt$platform=="aHiSeq_2",]
nextseq_1<-rlt[rlt$platform=="bNextSeq_1",]
nextseq_2<-rlt[rlt$platform=="bNextSeq_2",]
novaseq_1<-rlt[rlt$platform=="cNovaSeq_1",]
novaseq_2<-rlt[rlt$platform=="cNovaSeq_2",]

p_hiseq<-wilcox.test(hiseq_1$ERPM, hiseq_2$ERPM,alternative="two.sided")
p_nextseq<-wilcox.test(nextseq_1$ERPM, nextseq_2$ERPM,alternative="two.sided")
p_novaseq<-wilcox.test(novaseq_1$ERPM, novaseq_2$ERPM,alternative="two.sided")
p_values<-c(p_hiseq$p.value,p_nextseq$p.value,p_novaseq$p.value)


log10_ERPM<-log10(rlt[,"ERPM"]+0.1)
rlt<-cbind(rlt, log10_ERPM=log10_ERPM)
library(beeswarm)
zz<-beeswarm(rlt$log10_ERPM~rlt$platform,cex=1,do.plot =FALSE)
tmp<-cbind(zz$x,zz$y,zz$x.orig,zz$y.orig)
theX<-rep(-1,nrow(rlt))
theY<-rep(-1,nrow(rlt))
for(i in 1:nrow(rlt)) {
	curr_plat<-tmp[as.character(tmp[,3])==rlt[i,"platform"],]
	diffs<-abs(as.numeric(rlt[i,"log10_ERPM"])-as.numeric(curr_plat[,4]))
	rowno<-which(diffs<min(diffs)+1e-10)
	if(length(rowno)==0) {
		print(paste(i, " 0",sep=""))
	}
	if(length(rowno)>1) {
		print(paste(i, length(rowno),sep=" "))
	}
	if(length(rowno)==0) {
		print(i)
	} else {
		theX[i]<-as.numeric(as.character(curr_plat[rowno[1],1]))
	theY[i]<-as.numeric(as.character(curr_plat[rowno[1],2]))
	}
}

cols<-rep("skyblue",nrow(rlt))
cols[endsWith(as.character(rlt[,"platform"]),"_2")]<-"tomato"

rlt<-data.frame(rlt, theX=theX,theY=theY)
plats<-c("aHiSeq_1","aHiSeq_2","bNextSeq_1","bNextSeq_2","cNovaSeq_1","cNovaSeq_2")
for(i in 1:length(plats)) {
	curr_plat<-rlt[as.character(rlt[,1])==plats[i],]
	muX<-as.numeric(sprintf("%.0f",mean(as.numeric(as.character(curr_plat[,"theX"])))))
	maxX<-max(abs(as.numeric(as.character(curr_plat[,"theX"]))-muX))
	for(j in 1:nrow(rlt)) {
		if(as.character(rlt[j,1])==plats[i]) {
		rlt[j,"theX"]<-muX+0.25*(rlt[j,"theX"]-muX)/maxX
	}
	}	
}

use<-cols=="skyblue"

pdf("Cross_platform_Comparison_Mean_Surface.pdf",height=7,width=9,useDingbats=FALSE)
plot(rlt[use,"theX"],rlt[use,"theY"],col=cols[use],pch=1,yaxt="n",xaxt="n",ylim=c(-1.2,3.5),xlab="",ylab="Error Rate (per Million)",cex=0.6,xlim=c(0,7))
textHiSeq<-c(paste(c("HiSeq, 1\n(",sum(rlt[,"platform"]=="aHiSeq_1"),")"),collapse=""),paste(c("HiSeq, 2\n(",sum(rlt[,"platform"]=="aHiSeq_2"),")"),collapse=""))
textNextSeq<-c(paste(c("NextSeq, 1\n(",sum(rlt[,"platform"]=="bNextSeq_1"),")"),collapse=""),paste(c("NextSeq, 2\n(",sum(rlt[,"platform"]=="bNextSeq_2"),")"),collapse=""))
textNovaSeq<-c(paste(c("NovaSeq, 1\n(",sum(rlt[,"platform"]=="cNovaSeq_1"),")"),collapse=""),paste(c("NovaSeq, 2\n(",sum(rlt[,"platform"]=="cNovaSeq_2"),")"),collapse=""))
axis(1,at=c(1,2,3,4,5,6),labels=c(textHiSeq,textNextSeq,textNovaSeq),las=1)
axis(2,at=c(-1,0,1,2,3),labels=c(0.1,1,10,100,1000),las=1)
use<-cols!="skyblue"
points(rlt[use,"theX"],rlt[use,"theY"],col=cols[use],pch=1,cex=0.6)

for(i in 1:length(plats)) {
	med<-as.numeric(median(rlt[as.character(rlt[,1])==plats[i],"ERPM"]))
	lines(c(i-0.3,i+0.3),c(log10(0.1+med),log10(0.1+med)),lwd=2,col="black")
	text(i,log10(1+med),sprintf("%.1f",med),pos=1)
}

for (i in 1:length(p_values)){
	lines(c(i*2-1,i*2),c(3,3),lwd=1,col="black")
	text(i*2-0.5,3.1,formatC(p_values[i],format = "e", digits = 2))
}
dev.off()




