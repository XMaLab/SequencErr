

randit<-function(dataa){
    ret<-dataa
    for(i in 1:length(dataa)) {
	  if(dataa[i]<0.01) {
	    ret[i]<-runif(1,min=0,max=0.01)
	  }
	  if(dataa[i]>0.3) {
	    ret[i]<-runif(1,min=0.3,max=0.32)
	  }
	}
	return(ret)
}

library(beeswarm)

rlt<-read.table("cross_platform_summary_outlierpercentage.txt",header=TRUE,sep="\t")

outlier_machine<-c("E00332","NS500183")

bad<-as.character(rlt[,"Instru"]) %in% outlier_machine 
rlt<-rlt[!bad,]

hi<-as.character(rlt[,"Platform"])=="aHiSeq"
nov<-as.character(rlt[,"Platform"])=="cNovaSeq"
nex<-as.character(rlt[,"Platform"])=="bNextSeq"

HiSeq_1o<-rlt[hi,"N1_pcn"]
HiSeq_2o<-rlt[hi,"N2_pcn"]

NovaSeq_1o<-rlt[nov,"N1_pcn"]
NovaSeq_2o<-rlt[nov,"N2_pcn"]

NextSeq_1o<-rlt[nex,"N1_pcn"]
NextSeq_2o<-rlt[nex,"N2_pcn"]

HiSeq_1<-randit(HiSeq_1o)
HiSeq_2<-randit(HiSeq_2o)
NovaSeq_1<-randit(NovaSeq_1o)
NovaSeq_2<-randit(NovaSeq_2o)
NextSeq_1<-randit(NextSeq_1o)
NextSeq_2<-randit(NextSeq_2o)


dataa<-list(NovaSeq_2=NovaSeq_2, NovaSeq_1=NovaSeq_1, NextSeq_2=NextSeq_2, NextSeq_1=NextSeq_1, HiSeq_2=HiSeq_2, HiSeq_1=HiSeq_1)
names(dataa)[1]<-paste(c("NovaSeq_2 (",length(NovaSeq_2),")"),collapse="")
names(dataa)[2]<-paste(c("NovaSeq_1 (",length(NovaSeq_1),")"),collapse="")
names(dataa)[3]<-paste(c("NextSeq_2 (",length(NextSeq_2),")"),collapse="")
names(dataa)[4]<-paste(c("NextSeq_1 (",length(NextSeq_1),")"),collapse="")
names(dataa)[5]<-paste(c("HiSeq_2 (",length(HiSeq_2),")"),collapse="")
names(dataa)[6]<-paste(c("HiSeq_1 (",length(HiSeq_1),")"),collapse="")
pdf("Outliers.pdf",height=8,width=10,useDingbats=FALSE)
beeswarm(dataa,horiz=TRUE,las=1,xlim=c(0,0.322),col=c("tomato","skyblue"),cex.axis=0.5,cex=0.3)
text(0.3,1.1,sum(NovaSeq_2>0.1))
text(0.3,2.1,sum(NovaSeq_1>0.1))
text(0.3,3.1,sum(NextSeq_2>0.1))
text(0.3,4.1,sum(NextSeq_1>0.1))
text(0.3,5.1,sum(HiSeq_2>0.1))
text(0.3,6.1,sum(HiSeq_1>0.1))
lines(c(0.1,0.1),c(0,7),lwd=1,lty=2)
dev.off()

