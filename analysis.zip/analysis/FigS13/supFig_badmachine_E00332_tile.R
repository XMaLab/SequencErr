
library(beeswarm)

#rlt<-read.table("../E00332_allflowcells.txt",header=TRUE,sep="\t",colClass=c(rep("character",3),"numeric"))
rlt<-read.table("E00332_allflowcells.txt",header=TRUE,sep="\t",colClass=c(rep("character",5),"numeric"))
instru_tile<-apply(rlt[,1:3],1,paste,collapse="_")
inital_colnames<-colnames(rlt)
log10_ERPM<-log10(0.01+rlt[,"ERPM"])
rlt<-cbind(instru_tile=instru_tile,rlt,log10_ERPM=log10_ERPM)

multiple<-table(instru_tile)
maxx<-max(multiple)
multiple<-names(multiple)

q50values<-NULL
for(i in 1:length(multiple)) {
	values<-rlt[rlt[,"instru_tile"]==multiple[i],"ERPM"]
	tmp<-c(values,rep(NA,maxx-length(values)))
	q50values<-cbind(q50values,tmp)
}
colnames(q50values)<-multiple
row.names(q50values)<-1:nrow(q50values)
value_result<-data.frame(q50values,check.names=F)

med_medians<-apply(value_result,2,median,na.rm=TRUE)
pdf("E00332_tiles_allflowcells_updated.pdf",width=8,height=10,useDingbats=FALSE)
par(mar=c(8,10,2,2))
mycols<-rep("skyblue",length(med_medians))
mycols[med_medians>100]<-"tomato"  #xma
#beeswarm(log10(0.1+new_value_result),horiz=TRUE,las=1,cex=0.4,xaxt="n",xlim=c(-1,4.1),pch=16,col=c("skyblue"),xlab="Error Rate (per Million)",cex.axis=0.6)
beeswarm(log10(0.1+value_result),horiz=TRUE,las=1,cex=0.2,xaxt="n",xlim=c(-1,4.1),pch=16,col=mycols,xlab="Error Rate (per Million)",cex.axis=0.6)
lines(c(2,2),c(0,length(med_medians)),type="l",col="gray",lty=2)  #xma
axis(1,at=c(0,1,2,3,4),labels=c(1,10,100,1000,10000),cex.axis=0.6)
bxplot(log10(0.1+value_result),add=TRUE,horiz=TRUE,probs=0.5,lwd=0.4)
for(i in 1:length(med_medians)) {	
	text(log10(0.06),i,sprintf("%.1f",med_medians[i]),pos=4,cex=0.8)
}
dev.off()


