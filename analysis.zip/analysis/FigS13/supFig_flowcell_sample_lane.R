
sample_num_cutoff<-10
hiseq_samlple_cutoff<-15
library(beeswarm)
nextseq<-read.table("nextseq_flowcell_sample_lane.error.txt",header=TRUE,sep="\t")
novaseq<-read.table("novaseq_flowcell_sample_lane.error.txt",header=TRUE,sep="\t")
hiseq<-read.table("hiseq_flowcell_sample_lane.error.txt",header=TRUE,sep="\t")
sum_hi<-hiseq[hiseq[,"Total"]>1000000,]
sum_next<-nextseq[nextseq[,"Total"]>1000000,]
sum_nova<-novaseq[novaseq[,"Total"]>1000000,]
rlt<-rbind(sum_hi,sum_next,sum_nova)
colnames(rlt)<-c("platform","instrument","flowcell","lane","sample","Mismatch","Total","ERPM")

write.table(rlt, "platform_instrument_flowcell_sample_lane_summary.txt",row.names=F,col.names=TRUE,sep="\t",quote=F)

rlt<-read.table("platform_instrument_flowcell_sample_lane_summary.txt",header=TRUE,sep="\t")

plat_instru_flowcell<-apply(rlt[,1:4],1,paste,collapse="_")
multiple<-table(plat_instru_flowcell)
maxx<-max(multiple)

hiseq_flowcelllane_with_fewersamples<-names(multiple[startsWith(names(multiple),"aHiSeq") & multiple<hiseq_samlple_cutoff])
multiple<-names(multiple)[multiple>sample_num_cutoff]
multiple<-multiple[!(multiple %in% hiseq_flowcelllane_with_fewersamples)]	## obtain machine names that has multiple flowcells
log10_ERPM<-log10(rlt[,"ERPM"]+0.1)

rlt<-cbind(plat_instru_flowcell=plat_instru_flowcell, rlt, log10_ERPM=log10_ERPM)[plat_instru_flowcell %in% multiple,]

q50values<-NULL
for(i in 1:length(multiple)) {
	values<-rlt[as.character(rlt[,"plat_instru_flowcell"])==multiple[i],"ERPM"]
	tmp<-c(values,rep(NA,maxx-length(values)))	
	q50values<-cbind(q50values,tmp)
}

colnames(q50values)<-multiple
row.names(q50values)<-1:nrow(q50values)
value_result<-data.frame(q50values,check.names=F)
med_medians<-apply(value_result,2,median,na.rm=TRUE)
print (multiple)

platform<-matrix(unlist(strsplit(multiple,split="_")),ncol=4,byrow=TRUE)[,1]
ord<-order(platform,med_medians,decreasing=TRUE)
print(med_medians)

new_value_result_tmp<-value_result[,ord]
#print(new_value_result_tmp)
med_medians<-apply(new_value_result_tmp,2,median,na.rm=TRUE)
new_value_result<-new_value_result_tmp[,med_medians>0]
print (dim(new_value_result))
med_medians<-med_medians[med_medians>0]
#print (length(med_medians))

for(i in 1:ncol(new_value_result)) {
	colnames(new_value_result)[i]<-gsub("bNextSeq","NextSeq",gsub("cNovaSeq","NovaSeq",gsub("aHiSeq","HiSeq",colnames(new_value_result)[i])))
	colnames(new_value_result)[i]<-paste(c(colnames(new_value_result)[i], " (", sum(!is.na(new_value_result[,i])),")"),collapse="")
}

pdf("supFig_platform_flowcell_sample_lane.pdf",width=8,height=15,useDingbats=FALSE)
par(mar=c(8,10,2,2))
mycols<-rep("skyblue",length(med_medians))
mycols[med_medians>100]<-"tomato"  #xma
#beeswarm(log10(0.1+new_value_result),horiz=TRUE,las=1,cex=0.4,xaxt="n",xlim=c(-1,4.1),pch=16,col=c("skyblue"),xlab="Error Rate (per Million)",cex.axis=0.6)
beeswarm(log10(0.1+new_value_result),horiz=TRUE,las=1,cex=0.3,xaxt="n",xlim=c(-1,3.1),pch=16,col=mycols,xlab="Error Rate (per Million)",cex.axis=0.4)
print(nrow(new_value_result))
lines(c(2,2),c(0,length(med_medians)),type="l",col="gray",lty=2)  #xma
axis(1,at=c(-1,0,1,2,3),labels=c(0.1,1,10,100,1000),cex.axis=0.6)
bxplot(log10(0.1+new_value_result),add=TRUE,horiz=TRUE,probs=0.5,lwd=0.4)
for(i in 1:length(med_medians)) {	
	text(log10(0.06),i,sprintf("%.1f",med_medians[i]),pos=4,cex=0.8)
}
dev.off()


