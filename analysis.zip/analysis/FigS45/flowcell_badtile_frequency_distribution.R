
library (ggpubr)
background_control<-theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background =element_rect(fill = "white", colour = "grey50"))
badmachines<-c("NS500183","E00332")
data1<-read.table("hiseq_badtile.txt",sep="\t",header=T)
data1<-data1[data1$surface==1,]
machines<-matrix(unlist(strsplit(as.character(data1$flowcell),split="_")),ncol=2,byrow=TRUE)[,1]
data1<-data1[!(machines %in% badmachines),]
tile_table<-table(as.character(data1[,"badtile"]))
data1<-data.frame(as.numeric(names(tile_table)),tile_table)
colnames(data1)<-c("tile","xx","frequency")
p1<- ggplot(data=data1, aes(x=tile, y=frequency))+geom_bar(stat="identity")+background_control+ggtitle("Frequency of Badtile in Hiseq (top)")+xlab("Tile ID")+ylab("Count")

data1_2<-read.table("hiseq_badtile.txt",sep="\t",header=T)
data1_2<-data1_2[data1_2$surface==2,]
machines<-matrix(unlist(strsplit(as.character(data1_2$flowcell),split="_")),ncol=2,byrow=TRUE)[,1]
data1_2<-data1_2[!(machines %in% badmachines),]
tile_table<-table(as.character(data1_2[,"badtile"]))
data1_2<-data.frame(as.numeric(names(tile_table)),tile_table)
colnames(data1_2)<-c("tile","xx","frequency")
p1_2<- ggplot(data=data1_2, aes(x=tile, y=frequency))+geom_bar(stat="identity")+background_control+ggtitle("Frequency of Badtile in Hiseq (bottom)")+xlab("Tile ID")+ylab("Count")


data2<-read.table("nextseq_badtile.txt",sep="\t",header=T)
data2<-data2[data2$surface==1,]
machines<-matrix(unlist(strsplit(as.character(data2$flowcell),split="_")),ncol=2,byrow=TRUE)[,1]
data2<-data2[!(machines %in% badmachines),]
tile_table<-table(as.character(data2[,"badtile"]))
data2<-data.frame(as.numeric(names(tile_table)),tile_table)
colnames(data2)<-c("tile","xx","frequency")
p2<- ggplot(data=data2, aes(x=tile, y=frequency))+geom_bar(stat="identity")+background_control+ggtitle("Frequency of Badtile in Nextseq (top)")+xlab("Tile ID")+ylab("Count")+scale_x_discrete(limit = seq(1,12))

data2_2<-read.table("nextseq_badtile.txt",sep="\t",header=T)
data2_2<-data2_2[data2_2$surface==2,]
machines<-matrix(unlist(strsplit(as.character(data2_2$flowcell),split="_")),ncol=2,byrow=TRUE)[,1]
data2_2<-data2_2[!(machines %in% badmachines),]
tile_table<-table(as.character(data2_2[,"badtile"]))
data2_2<-data.frame(as.numeric(names(tile_table)),tile_table)
colnames(data2_2)<-c("tile","xx","frequency")
p2_2<- ggplot(data=data2_2, aes(x=tile, y=frequency))+geom_bar(stat="identity")+background_control+ggtitle("Frequency of Badtile in Nextseq (bottom)")+xlab("Tile ID")+ylab("Count")+scale_x_discrete(limit = seq(1,12))

data3<-read.table("novaseq_badtile.txt",sep="\t",header=T)
data3<-data3[data3$surface==1,]
machines<-matrix(unlist(strsplit(as.character(data3$flowcell),split="_")),ncol=2,byrow=TRUE)[,1]
data3<-data3[!(machines %in% badmachines),]
tile_table<-table(as.character(data3[,"badtile"]))
data3<-data.frame(as.numeric(names(tile_table)),tile_table)
colnames(data3)<-c("tile","xx","frequency")
p3<- ggplot(data=data3, aes(x=tile, y=frequency))+geom_bar(stat="identity")+background_control+ggtitle("Frequency of Badtile in Novaseq (top)")+xlab("Tile ID")+ylab("Count")

data3_2<-read.table("novaseq_badtile.txt",sep="\t",header=T)
data3_2<-data3_2[data3_2$surface==2,]
machines<-matrix(unlist(strsplit(as.character(data3_2$flowcell),split="_")),ncol=2,byrow=TRUE)[,1]
data3_2<-data3_2[!(machines %in% badmachines),]
tile_table<-table(as.character(data3_2[,"badtile"]))
data3_2<-data.frame(as.numeric(names(tile_table)),tile_table)
colnames(data3_2)<-c("tile","xx","frequency")
p3_2<- ggplot(data=data3_2, aes(x=tile, y=frequency))+geom_bar(stat="identity")+background_control+ggtitle("Frequency of Badtile in Novaseq (bottom)")+xlab("Tile ID")+ylab("Count")

pdf("badtile_distribution.pdf",width=8,height=10)
ggarrange(p1,p1_2,p2,p2_2,p3,p3_2,ncol=2,nrow=3)
dev.off()

data4<-read.table("hiseq_badtile_percentage.txt",sep="\t",header=T)
data4<-data4[data4$surface==1,]
machines<-matrix(unlist(strsplit(as.character(data4$flowcell),split="_")),ncol=2,byrow=TRUE)[,1]
data4<-data4[!(machines %in% badmachines),]
bins<-seq(from=0,to=100)
counts<-rep(0,101)
for (i in bins){
	if (i==0){
		counts[1]<-sum((data4$badtiles==0)) 
	}else{
		counts[i+1]<-sum((data4$badtile_percentage>i-1) & data4$badtile_percentage<=i)
	}
}
bad_flowcell_percn<-sprintf("%.1f",100*sum(data4$badtiles>0)/nrow(data4))
tmp_data<-data.frame(bins=bins,counts=counts)
p4<- ggplot(data=tmp_data, aes(x=bins,y=counts)) + geom_bar(stat="identity")+background_control+ggtitle("Badtile percentage in Hiseq (top)")+xlab("bad tile percentage(%)")+ylab("Count")+annotate("text", y=max(counts), x =50,label=paste("bad flowcell percentage( ",bad_flowcell_percn,"%)",sep=""))

data4_2<-read.table("hiseq_badtile_percentage.txt",sep="\t",header=T)
data4_2<-data4_2[data4_2$surface==2,]
machines<-matrix(unlist(strsplit(as.character(data4_2$flowcell),split="_")),ncol=2,byrow=TRUE)[,1]
data4_2<-data4_2[!(machines %in% badmachines),]
bins<-seq(from=0,to=100)
counts<-rep(0,101)
for (i in bins){
	if (i==0){
		counts[1]<-sum((data4_2$badtiles==0)) 
	}else{
		counts[i+1]<-sum((data4_2$badtile_percentage>i-1) & data4_2$badtile_percentage<=i)
	}
}

bad_flowcell_percn<-sprintf("%.1f",100*sum(data4_2$badtiles>0)/nrow(data4_2))
tmp_data<-data.frame(bins=bins,counts=counts)
p4_2<- ggplot(data=tmp_data, aes(x=bins,y=counts)) + geom_bar(stat="identity")+background_control+ggtitle("Badtile percentage in Hiseq (bottom)")+xlab("bad tile percentage(%)")+ylab("Count")+annotate("text", y=max(counts), x =50,label=paste("bad flowcell percentage( ",bad_flowcell_percn,"%)",sep=""))


data5<-read.table("nextseq_badtile_percentage.txt",sep="\t",header=T)
data5<-data5[data5$surface==1,]
machines<-matrix(unlist(strsplit(as.character(data5$flowcell),split="_")),ncol=2,byrow=TRUE)[,1]
data5<-data5[!(machines %in% badmachines),]
bins<-seq(from=0,to=100)
counts<-rep(0,101)
for (i in bins){
	if (i==0){
		counts[1]<-sum((data5$badtiles==0)) 
	}else{
		counts[i+1]<-sum((data5$badtile_percentage>i-1) & data5$badtile_percentage<=i)
	}
}

bad_flowcell_percn<-sprintf("%.1f",100*sum(data5$badtiles>0)/nrow(data5))
tmp_data<-data.frame(bins=bins,counts=counts)
p5<- ggplot(data=tmp_data, aes(x=bins,y=counts)) + geom_bar(stat="identity")+background_control+ggtitle("Badtile percentage in Nextseq (top)")+xlab("bad tile percentage(%)")+ylab("Count")+annotate("text", y=max(counts), x =50,label=paste("bad flowcell percentage( ",bad_flowcell_percn,"%)",sep=""))

data5_2<-read.table("nextseq_badtile_percentage.txt",sep="\t",header=T)
data5_2<-data5_2[data5_2$surface==2,]
machines<-matrix(unlist(strsplit(as.character(data5_2$flowcell),split="_")),ncol=2,byrow=TRUE)[,1]
data5_2<-data5_2[!(machines %in% badmachines),]
bins<-seq(from=0,to=100)
counts<-rep(0,101)
for (i in bins){
	if (i==0){
		counts[1]<-sum((data5_2$badtiles==0)) 
	}else{
		counts[i+1]<-sum((data5_2$badtile_percentage>i-1) & data5_2$badtile_percentage<=i)
	}
}
bad_flowcell_percn<-sprintf("%.1f",100*sum(data5_2$badtiles>0)/nrow(data5_2))
tmp_data<-data.frame(bins=bins,counts=counts)
p5_2<- ggplot(data=tmp_data, aes(x=bins,y=counts)) + geom_bar(stat="identity")+background_control+ggtitle("Badtile percentage in Nextseq (bottom)")+xlab("bad tile percentage(%)")+ylab("Count")+annotate("text", y=max(counts), x =50,label=paste("bad flowcell percentage( ",bad_flowcell_percn,"%)",sep=""))

data6<-read.table("novaseq_badtile_percentage.txt",sep="\t",header=T)
data6<-data6[data6$surface==1,]
machines<-matrix(unlist(strsplit(as.character(data6$flowcell),split="_")),ncol=2,byrow=TRUE)[,1]
data6<-data6[!(machines %in% badmachines),]
bins<-seq(from=0,to=100)
counts<-rep(0,101)
for (i in bins){
	if (i==0){
		counts[1]<-sum((data6$badtiles==0)) 
	}else{
		counts[i+1]<-sum((data6$badtile_percentage>i-1) & data6$badtile_percentage<=i)
	}
}

bad_flowcell_percn<-sprintf("%.1f",100*sum(data6$badtiles>0)/nrow(data6))
tmp_data<-data.frame(bins=bins,counts=counts)
p6<- ggplot(data=tmp_data, aes(x=bins,y=counts)) + geom_bar(stat="identity")+background_control+ggtitle("Badtile percentage in Novaseq (top)")+xlab("bad tile percentage(%)")+ylab("Count")+annotate("text", y=max(counts), x =50,label=paste("bad flowcell percentage( ",bad_flowcell_percn,"%)",sep=""))

data6_2<-read.table("novaseq_badtile_percentage.txt",sep="\t",header=T)
data6_2<-data6_2[data6_2$surface==2,]
machines<-matrix(unlist(strsplit(as.character(data6_2$flowcell),split="_")),ncol=2,byrow=TRUE)[,1]
data6_2<-data6_2[!(machines %in% badmachines),]
bins<-seq(from=0,to=100)
counts<-rep(0,101)
for (i in bins){
	if (i==0){
		counts[1]<-sum((data6_2$badtiles==0)) 
	}else{
		counts[i+1]<-sum((data6_2$badtile_percentage>i-1) & data6_2$badtile_percentage<=i)
	}
}

bad_flowcell_percn<-sprintf("%.1f",100*sum(data6_2$badtiles>0)/nrow(data6_2))
tmp_data<-data.frame(bins=bins,counts=counts)
p6_2<- ggplot(data=tmp_data, aes(x=bins,y=counts)) + geom_bar(stat="identity")+background_control+ggtitle("Badtile percentage in Novaseq (bottom)")+xlab("bad tile percentage(%)")+ylab("Count")+annotate("text", y=max(counts), x =50,label=paste("bad flowcell percentage( ",bad_flowcell_percn,"%)",sep=""))
pdf("flowcell_badtile_frequency.pdf",width=8,height=10)
ggarrange(p4,p4_2,p5,p5_2,p6,p6_2,ncol=2,nrow=3)
dev.off()
