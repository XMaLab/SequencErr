
library(beeswarm)
nextseq<-read.table("nextseq_error_rates_all_2.txt",header=TRUE,sep="\t")
novaseq<-read.table("novaseq_error_rates_all_2.txt",header=TRUE,sep="\t")
hiseq<-read.table("hiseq_error_rates_all_2.txt",header=TRUE,sep="\t")
sum_hi<-hiseq[hiseq[,"total"]>2000000,]
sum_next<-nextseq[nextseq[,"total"]>2000000,]
sum_nova<-novaseq[novaseq[,"total"]>2000000,]
rlt<-rbind(sum_hi,sum_next,sum_nova)
colnames(rlt)<-c("platform","instrument","flowcell","mismatch","total","ERPM")

write.table(rlt, "cross_Instrument_summary_Mean.txt",row.names=F,col.names=TRUE,sep="\t",quote=F)

rlt<-read.table("cross_Instrument_summary_Mean.txt",header=TRUE,sep="\t")

Machine<-apply(rlt[,1:2],1,paste,collapse="_")
multiple<-table(Machine)
maxx<-max(multiple)

multiple<-names(multiple[(startsWith(names(multiple),"bNextSeq"))|(startsWith(names(multiple),"cNovaSeq"))])	## obtain machine names that has multiple flowcells
log10_ERPM<-log10(rlt[,"ERPM"]+0.1)
rlt<-cbind(Machine=Machine,rlt, log10_ERPM=log10_ERPM)[Machine %in% multiple,]

q50values<-NULL
for(i in 1:length(multiple)) {
	values<-rlt[as.character(rlt[,"Machine"])==multiple[i],"ERPM"]
	tmp<-c(values,rep(NA,maxx-length(values)))	
	q50values<-cbind(q50values,tmp)
}
print(q50values)
colnames(q50values)<-multiple
row.names(q50values)<-1:nrow(q50values)
value_result<-data.frame(q50values,check.names=F)
med_medians<-apply(value_result,2,median,na.rm=TRUE)
platform<-matrix(unlist(strsplit(multiple,split="_")),ncol=2,byrow=TRUE)[,1]
ord<-order(platform,med_medians,decreasing=TRUE)
new_value_result<-value_result[,ord]
med_medians<-apply(new_value_result,2,median,na.rm=TRUE)


for(i in 1:ncol(new_value_result)) {
	colnames(new_value_result)[i]<-gsub("bNextSeq","NextSeq",gsub("cNovaSeq","NovaSeq",gsub("aHiSeq","HiSeq",colnames(new_value_result)[i])))
	colnames(new_value_result)[i]<-paste(c(colnames(new_value_result)[i], " (", sum(!is.na(new_value_result[,i])),")"),collapse="")
}

pdf("Cross_Instrument_Check_mean_all_NextNovaseq.pdf",width=5,height=5,useDingbats=FALSE)
par(mar=c(8,10,2,2))
mycols<-rep("skyblue",length(med_medians))
mycols[med_medians>100]<-"tomato"  #xma
beeswarm(log10(0.1+new_value_result),horiz=TRUE,las=1,cex=0.3,xaxt="n",xlim=c(-1,4.1),pch=16,col=mycols,xlab="Error Rate (per Million)",cex.axis=0.3)
lines(c(2,2),c(0,length(med_medians)),type="l",col="gray",lty=2)  #xma
axis(1,at=c(-1,0,1,2,3,4),labels=c(0.1,1,10,100,1000,10000),cex.axis=0.3)
bxplot(log10(0.1+new_value_result),add=TRUE,horiz=TRUE,probs=0.5,lwd=1)
for(i in 1:length(med_medians)) {	
	text(log10(0.05),i,sprintf("%.1f",med_medians[i]),pos=4,cex=0.5)
}
dev.off()


