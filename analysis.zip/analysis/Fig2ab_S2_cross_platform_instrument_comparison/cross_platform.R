
nextseq<-read.table("nextseq_error_rates_all_2.txt",header=TRUE,sep="\t")
novaseq<-read.table("novaseq_error_rates_all_2.txt",header=TRUE,sep="\t")
hiseq<-read.table("hiseq_error_rates_all_2.txt",header=TRUE,sep="\t")
sum_hi<-hiseq[hiseq[,"total"]>2000000,]
sum_next<-nextseq[nextseq[,"total"]>2000000,]
sum_nova<-novaseq[novaseq[,"total"]>2000000,]
rlt<-rbind(sum_hi,sum_next,sum_nova)
colnames(rlt)<-c("platform","instrument","flowcell","mismatch","total","ERPM")

log10_ERPM<-log10(rlt[,"ERPM"]+0.1)
rlt<-cbind(rlt, log10_ERPM=log10_ERPM)
write.table(rlt,"cross_Instrument_summary_Mean.txt",row.names=F,col.names=TRUE,sep="\t", quote=F)
library(beeswarm)
zz<-beeswarm(rlt$log10_ERPM~rlt$platform,cex=2,do.plot =FALSE)
tmp<-cbind(zz$x,zz$y,zz$x.orig,zz$y.orig)
theX<-rep(-1,nrow(rlt))
theY<-rep(-1,nrow(rlt))
for(i in 1:nrow(rlt)) {
	curr_plat<-tmp[as.character(tmp[,3])==rlt[i,"platform"],]
	diffs<-abs(as.numeric(rlt[i,"log10_ERPM"])-as.numeric(curr_plat[,4]))
	rowno<-which(diffs<min(diffs)+1e-10)
	if(length(rowno)==0) {
		print(i)
	} else {
		theX[i]<-as.numeric(as.character(curr_plat[rowno[1],1]))
	theY[i]<-as.numeric(as.character(curr_plat[rowno[1],2]))
	}
}

outlier_instrument<-c("E00332","NS500183")
outlier_flowcell<-c("C5E39ANXX_nouse")
cols<-rep("skyblue",nrow(rlt))
cols[as.character(rlt[,"instrument"]) %in% outlier_instrument|as.character(rlt[,"flowcell"]) %in% outlier_flowcell]<-"tomato"
rlt<-data.frame(rlt, theX=theX,theY=theY,cols=cols)
plats<-c("aHiSeq","bNextSeq","cNovaSeq")
for(i in 1:length(plats)) {
	curr_plat<-rlt[as.character(rlt[,1])==plats[i],]
	muX<-as.numeric(sprintf("%.0f",mean(as.numeric(as.character(curr_plat[,"theX"])))))
	maxX<-max(abs(as.numeric(as.character(curr_plat[,"theX"]))-muX))
	for(j in 1:nrow(rlt)) {
		if(as.character(rlt[j,1])==plats[i]) {
		rlt[j,"theX"]<-muX+0.25*(rlt[j,"theX"]-muX)/maxX
	}
	}	
}


use<-cols=="skyblue"

pdf("Cross_platform_Comparison_Mean.pdf",height=9,width=5,useDingbats=FALSE)
plot(rlt[use,"theX"],rlt[use,"theY"],col=cols[use],pch=1,yaxt="n",xaxt="n",ylim=c(-1,3.5),xlab="",ylab="Error Rate (per Million)",cex=0.6,xlim=c(0.5,3.5))
textHiSeq<-paste(c("HiSeq (",sum(rlt[,"platform"]=="aHiSeq"),")"),collapse="")
textNextSeq<-paste(c("NextSeq (",sum(rlt[,"platform"]=="bNextSeq"),")"),collapse="")
textNovaSeq<-paste(c("NovaSeq (",sum(rlt[,"platform"]=="cNovaSeq"),")"),collapse="")
axis(1,at=c(1,2,3),labels=c(textHiSeq,textNextSeq,textNovaSeq),las=1)
axis(2,at=c(-1,0,1,2,3),labels=c(0.1,1,10,100,1000),las=1)
use<-cols!="skyblue"
points(rlt[use,"theX"],rlt[use,"theY"],col=cols[use],pch=1,cex=0.6)

for(i in 1:length(plats)) {
	med<-as.numeric(median(rlt[as.character(rlt[,1])==plats[i] & cols=="skyblue","ERPM"]))
	lines(c(i-0.3,i+0.3),c(log10(0.1+med),log10(0.1+med)),lwd=2,col="black")
	text(i,log10(0.1+med),sprintf("%.1f",med),pos=1)
}
dev.off()


