
epsilon<-1/10000000
mkr<-read.table("markers.txt",header=TRUE,sep="\t",colClass=c("character","integer",rep("character",3)))
mkr[,1]<-gsub("chr","",mkr[,1])
row.names(mkr)<-apply(cbind(as.character(mkr[,1]),as.character(mkr[,2])),1,paste,collapse="_")

extract_data<-function(fn, mkrs,minN) {
  datas<-read.table(fn,header=TRUE,sep="\t",colClass=c("character",rep("integer",6)))
  nnn<-grep("GL",datas[,1],value=TRUE)
  datas<-datas[!(datas[,1] %in% nnn),]
  colnames(datas)<-c("Chr","Pos","A","C","G","T","N")
  tmp<-matrix(unlist(strsplit(datas[,1],split=".",fixed=TRUE)),ncol=2,byrow=TRUE)
  datas[,1]<-tmp[,1]
  needs<-rep(FALSE,nrow(datas)) 
  for(i in 1:nrow(mkrs)) {
	tmp<-which(as.character(datas[,1])==as.character(mkrs[i,1]) & abs(datas[,2]-mkrs[i,2])<1000 & as.numeric(datas[,"N"])>minN)
			needs[tmp]<-TRUE
  }
  rlt<-datas[needs,]
  row.names(rlt)<-apply(cbind(as.character(rlt[,1]),as.character(rlt[,2])),1,paste,collapse="_")
   return(rlt)
}


extract_data_v2<-function(fn, sites) {
  datas<-read.table(fn,header=TRUE,sep="\t",colClass=c("character",rep("integer",6)))
  nnn<-grep("GL",datas[,1],value=TRUE)
  datas<-datas[!(datas[,1] %in% nnn),]
  colnames(datas)<-c("Chr","Pos","A","C","G","T","N")
  tmp<-matrix(unlist(strsplit(datas[,1],split=".",fixed=TRUE)),ncol=2,byrow=TRUE)
  datas[,1]<-tmp[,1]
  row.names(datas)<-apply(cbind(as.character(datas[,1]),as.character(datas[,2])),1,paste,collapse="_")
  rlt<-datas[sites,]
  return(rlt)
}

join_data<-function(da,db,a_tag,b_tag) {
  row.names(da)<-apply(cbind(as.character(da[,1]),as.character(da[,2])),1,paste,collapse=".")
  row.names(db)<-apply(cbind(as.character(db[,1]),as.character(db[,2])),1,paste,collapse=".")
  common<-intersect(row.names(da),row.names(db))
  da<-da[common,]
  db<-db[common,]
  colnames(da)[3:7]<-paste(a_tag,colnames(da)[3:7],sep="")
  colnames(db)<-paste(b_tag,colnames(db),sep="")
  rlt<-cbind(da[,1:7],db[,3:8])
  return(rlt) 
}

obtain_sites<-function(markerset) {
  minN<-100000
  fns<-dir(path="./nofilter",pattern="count_4Fig3c")
  use<-NULL
  for(i in 1:length(fns)) {
    tmp<-extract_data(paste(c("./nofilter/",fns[i]),collapse=""),mkrs=mkr,minN=minN)
    use<-union(use,row.names(tmp))  
    print(i)
  }
  use<-setdiff(use,markerset)
  return(use)
}


merge_replicates<-function(fn1,sites) {
  d1<-extract_data_v2(fn1, sites)
  A<-d1[,"A"]
  C<-d1[,"C"]
  G<-d1[,"G"]
  T<-d1[,"T"]
  N<-d1[,"N"]
  rlt<-cbind(d1[,1:2],A,C,G,T,N)
  geno<-rep("",nrow(rlt))
  geno[A>0.9*N]<-"A"
  geno[C>0.9*N]<-"C"
  geno[G>0.9*N]<-"G"
  geno[T>0.9*N]<-"T"
  rlt<-cbind(rlt,geno)
  return(rlt)  
}


markerset<-c("1_153391729","1_153391786")
sites<-obtain_sites(markerset)

fn1<-"./nofilter/count_4Fig3c_HAIB.HAIB_Colo829_1v1000_NovaSeq_Q5"
HAIB_Colo829_1v1000<-merge_replicates(fn1,sites)
fn1<-"./nofilter/count_4Fig3c_HAIB.HAIB_Colo829_2v10000_NovaSeq_Q5"
HAIB_Colo829_2v10000<-merge_replicates(fn1,sites)
fn1<-"./nofilter/count_4Fig3c_SJ.Colo829_1v1000_NovaSeq_Q5"
SJ_Colo829_1v1000<-merge_replicates(fn1,sites)
fn1<-"./nofilter/count_4Fig3c_SJ.Colo829_1v5000_NovaSeq_Q5"
SJ_Colo829_1v5000<-merge_replicates(fn1,sites)

fn1<-"./filter/count_4Fig3c_HAIB.HAIB_Colo829_1v1000_NovaSeq_Q5"
F_HAIB_Colo829_1v1000<-merge_replicates(fn1,sites)
fn1<-"./filter/count_4Fig3c_HAIB.HAIB_Colo829_2v10000_NovaSeq_Q5"
F_HAIB_Colo829_2v10000<-merge_replicates(fn1,sites)
fn1<-"./filter/count_4Fig3c_SJ.Colo829_1v1000_NovaSeq_Q5"
F_SJ_Colo829_1v1000<-merge_replicates(fn1,sites)
fn1<-"./filter/count_4Fig3c_SJ.Colo829_1v5000_NovaSeq_Q5"
F_SJ_Colo829_1v5000<-merge_replicates(fn1,sites)

minN<-200000


plot_pair<-function(aff,bff,letterss,revl,ref,mut,main,mkr) {
  needss<-as.character(bff[,"geno"])==ref
  val_1.bff<-(bff[needss,mut]/bff[needss,"N"]+epsilon)
  val_1.aff<-(aff[needss,mut]/aff[needss,"N"]+epsilon)
  cols1<-rep("#111111",sum(needss))  
  thenames<-row.names(bff)[needss]
  goods<-row.names(mkr)[(as.character(mkr[,"Ref"])==ref & as.character(mkr[,"Mut"])==mut)]
  cols1[thenames %in% goods]<-"red"
  

  ref2<-revl[letterss==ref]
  mut2<-revl[letterss==mut]
  needss<-as.character(bff[,"geno"])==ref2
  val_2.bff<-(bff[needss,mut2]/bff[needss,"N"]+epsilon)
  val_2.aff<-(aff[needss,mut2]/aff[needss,"N"]+epsilon)
  cols2<-rep("#111111",sum(needss))  
  thenames<-row.names(bff)[needss]
  goods<-row.names(mkr)[(as.character(mkr[,"Ref"])==ref & as.character(mkr[,"Mut"])==mut) | (as.character(mkr[,"Ref"])==ref2 & as.character(mkr[,"Mut"])==mut2)]
  cols2[thenames %in% goods]<-"red"

  val.bff<-c(val_1.bff,val_2.bff)
  val.aff<-c(val_1.aff,val_2.aff)
  colss<-c(cols1,cols2)
  pchs<-rep(1,length(colss))
  pchs[colss=="red"]<-16
  cexs<-rep(1,length(colss))
  cexs[colss=="red"]<-2
  use<-rep(FALSE,length(colss))
  use[colss=="red"]<-TRUE
  #abline(0,1,col="grey")
  #plot(val.bff,val.aff, panel.first =abline(0,1,col="grey"),main=paste(c(main, "(",ref,">",mut,"/",ref2,">",mut2,")"),collapse=""),col="#000000",pch=1,cex=1,xlab="With Bad Tiles",ylab="Remove Bad Tiles")
  fcg<-(val.bff/val.aff)
  fcg<-fcg[colss=="#111111"]
  minFC<-min(fcg)
  maxFC<-max(fcg)
  fcg[fcg>2]<-2.01
  pcnt<-sprintf("%.1f%% (%.1f, %.1f)",100*sum(fcg>2)/length(fcg),minFC,maxFC)
  breaks<-c(0.95,1+(0:10)/10+0.05)
  hist(fcg,main=paste(c(main, "(",ref,">",mut,"/",ref2,">",mut2,")"),collapse=""),col="#000000", breaks=breaks, xlim=c(0.8,2.2),freq=TRUE)
  text(1.5,100,pcnt)
  #points(val.bff[use],val.aff[use],col="red",pch=16,cex=2)
}  

do_one_comp<-function(bff,aff,minN,main,mkr) {
  common<-intersect(row.names(bff)[bff[,"N"]>minN],row.names(aff)[aff[,"N"]>minN])
  bff<-bff[common,]
  aff<-aff[common,]
  letterss<-c("A","C","G","T")
  revl<-c("T","G","C","A")
  kk<-NULL
  nms<-NULL
  par(mfrow=c(3,2))
  plot_pair(aff,bff,letterss,revl,ref="A",mut="C",main=main,mkr)
  plot_pair(aff,bff,letterss,revl,ref="A",mut="G",main=main,mkr)
  plot_pair(aff,bff,letterss,revl,ref="A",mut="T",main=main,mkr)
  plot_pair(aff,bff,letterss,revl,ref="C",mut="A",main=main,mkr)
  plot_pair(aff,bff,letterss,revl,ref="C",mut="G",main=main,mkr)
  plot_pair(aff,bff,letterss,revl,ref="C",mut="T",main=main,mkr)	
}


pdf("FigS8.pdf",height=10,width=6,useDingbats=FALSE)
bff<-HAIB_Colo829_1v1000; aff<-F_HAIB_Colo829_1v1000;
do_one_comp(bff,aff,minN,main="HAIB_Colo829_1v1000",mkr)

bff<-HAIB_Colo829_2v10000; aff<-F_HAIB_Colo829_2v10000;
do_one_comp(bff,aff,minN,main="HAIB_Colo829_2v10000",mkr)

bff<-SJ_Colo829_1v1000; aff<-F_SJ_Colo829_1v1000;
do_one_comp(bff,aff,minN,main="SJ_Colo829_1v1000",mkr)

bff<-SJ_Colo829_1v5000; aff<-F_SJ_Colo829_1v5000;
do_one_comp(bff,aff,minN,main="SJ_Colo829_1v5000",mkr)

dev.off()



print("A")
sum(row.names(HAIB_Colo829_1v1000)==row.names(F_HAIB_Colo829_1v1000))
print("b")
sum(row.names(HAIB_Colo829_2v10000)==row.names(F_HAIB_Colo829_2v10000))
print("c")
sum(row.names(SJ_Colo829_1v1000)==row.names(F_SJ_Colo829_1v1000))
print("d")
sum(row.names(SJ_Colo829_1v5000)==row.names(F_SJ_Colo829_1v5000))
print("e")
haib.1v1000<-cbind(HAIB_Colo829_1v1000,F_HAIB_Colo829_1v1000)
print("f")
haib.1v5000<-cbind(HAIB_Colo829_2v10000,F_HAIB_Colo829_2v10000)
print("g")
sj.1v1000<-cbind(SJ_Colo829_1v1000,F_SJ_Colo829_1v1000)
print("h")
sj.1v5000<-cbind(SJ_Colo829_1v5000,F_SJ_Colo829_1v5000)

write.table(haib.1v1000,"haib.1v1000.txt",sep="\t",row.names=F,col.names=FALSE,quote=F)
write.table(haib.1v5000,"haib.1v5000.txt",sep="\t",row.names=F,col.names=FALSE,quote=F)
write.table(sj.1v1000,"sj.1v1000.txt",sep="\t",row.names=F,col.names=FALSE,quote=F)
write.table(sj.1v5000,"sj.1v5000.txt",sep="\t",row.names=F,col.names=FALSE,quote=F)




