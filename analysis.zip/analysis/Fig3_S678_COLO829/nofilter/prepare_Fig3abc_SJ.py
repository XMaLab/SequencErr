import sys
import os
flank_length=500
coverage_cut=100000
SJ_samples={
	"Colo829_1v1000_NovaSeq_Q5":
		{"Rep1": "SRR7251197","Rep2":"SRR7251199"},
	"Colo829_1v5000_NovaSeq_Q5":
		{"Rep1": "SRR7251207", "Rep2":"SRR7251202"}

}
data={}
pairerror_pos={}
pairerror_data={}

germline_markers=["1.153391729","1.153391786"]
somatic_markers=[]
somatic_markers_fh=open ("markers.txt","r")
somatic_markers_fh.readline()
for line in somatic_markers_fh.readlines():
	lst=line.strip().split("\t")
	chr_pos=lst[0].replace("chr","")+"."+lst[1]
	somatic_markers.append(chr_pos)

removed_markers_4b = germline_markers+somatic_markers
removed_markers_4c = germline_markers
#get target region by extend flank_length of the somatic marker pos
target_region=[]
for i in somatic_markers:
	chro=i.split(".")[0]
	pos=i.split(".")[1]
	for j in range(int(pos)-flank_length,int(pos)+flank_length):
		target_region.append(chro+"."+str(j))

#read in pairerror files and save in pairerror_data
for sample in SJ_samples:
	for rep in SJ_samples[sample]:
		SRR_name=SJ_samples[sample][rep]
		if SRR_name not in pairerror_data:
			pairerror_data[SRR_name]={}
		pair_file="pairError."+SRR_name
		with open (pair_file, "r") as pair_fh:
			header_4a=pair_fh.readline()
			for line in pair_fh.readlines():
				lst=line.strip().split("\t")
				Instrument=lst[0]
				Flowcell=lst[1]
				Lane=lst[2]
				Tile=lst[3]
				tile_info=(".").join(lst[0:4])
				pairerror_pos[tile_info]=1
				content=lst[4:]
				pairerror_data[SRR_name][tile_info]=content

# read in seq result files and save the result in data 
for sample in SJ_samples:
	for rep in SJ_samples[sample]:
		SRR_name=SJ_samples[sample][rep]
		if SRR_name not in data:
			data[SRR_name]={}
		count_file="counts."+SRR_name
		with open (count_file,"r")as count_fh:
			count_fh.readline()
			for line in count_fh.readlines():
				lst=line.strip().split("\t")
				chr_pos=lst[0]+"."+lst[1]
				#pos=lst[1]
				#A_Q_30=lst[2]
				#C_Q_30=lst[3]
				#G_Q_30=lst[4]
				#T_Q_30=lst[5]
				#N_Q_30=lst[6]
				data[SRR_name][chr_pos]=lst

#output 3a file
out_4a_file="pairError.3a_SJ"
out_4a_fh=open (out_4a_file,"w")
out_4a_fh.write(header_4a)
for tile in sorted (pairerror_pos.keys()):
	content=[0]*len(header_4a.strip().split("\t")[4:])
	for i in range(len(header_4a.strip().split("\t")[4:])):
		for sample in pairerror_data:
			if tile in pairerror_data[sample]:
				content[i]+=int(pairerror_data[sample][tile][i])
	content_str=[str(mm) for mm in content]
	out_4a_fh.write(("\t").join(tile.split("."))+"\t"+("\t").join(content_str)+"\n")

out_4a_fh.close()
				
#output 3b files
out_4b=open("count_4Fig3b_SJ","w")
out_4b.write("Chr.Pos\tPos\tA_Q_30\tC_Q_30\tG_Q_30\tT_Q_30\tN_Q_30\n")
for chr_pos in target_region:
	if chr_pos in removed_markers_4b:
		continue
	A_Q_30=0
	C_Q_30=0
	G_Q_30=0
	T_Q_30=0
	N_Q_30=0
	for sample in data:
		if chr_pos in data[sample]:
			A_Q_30+=int(data[sample][chr_pos][2])
			C_Q_30+=int(data[sample][chr_pos][3])
			G_Q_30+=int(data[sample][chr_pos][4])
			T_Q_30+=int(data[sample][chr_pos][5])
			N_Q_30+=int(data[sample][chr_pos][6])
	if N_Q_30>coverage_cut:
		out_4b.write(chr_pos+"\t"+chr_pos.split(".")[1]+"\t"+str(A_Q_30)+"\t"+str(C_Q_30)+"\t"+str(G_Q_30)+"\t"+str(T_Q_30)+"\t"+str(N_Q_30)+"\n")
out_4b.close()

#output 3c files
for sample in SJ_samples:
	out_file="count_4Fig3c_SJ."+sample
	out_fh=open(out_file,"w")
	out_fh.write("Chr.Pos\tPos\tA_Q_30\tC_Q_30\tG_Q_30\tT_Q_30\tN_Q_30\n")
	for chr_pos in target_region:
		if chr_pos in removed_markers_4c:
			continue
		A_Q_30=0
		C_Q_30=0
		G_Q_30=0
		T_Q_30=0
		N_Q_30=0
		for rep in SJ_samples[sample]:
			SRR_name=SJ_samples[sample][rep]
			if chr_pos in data[SRR_name]:
				A_Q_30+=int(data[SRR_name][chr_pos][2])
				C_Q_30+=int(data[SRR_name][chr_pos][3])
				G_Q_30+=int(data[SRR_name][chr_pos][4])
				T_Q_30+=int(data[SRR_name][chr_pos][5])
				N_Q_30+=int(data[SRR_name][chr_pos][6])
		if N_Q_30>coverage_cut:
			out_fh.write(chr_pos+"\t"+chr_pos.split(".")[1]+"\t"+str(A_Q_30)+"\t"+str(C_Q_30)+"\t"+str(G_Q_30)+"\t"+str(T_Q_30)+"\t"+str(N_Q_30)+"\n")
	out_fh.close()
	
	
