
mkr<-read.table("markers.txt",header=TRUE,sep="\t",colClass=c("character","integer",rep("character",3)))
mkr[,1]<-gsub("chr","",mkr[,1])
row.names(mkr)<-apply(cbind(as.character(mkr[,1]),as.character(mkr[,2])),1,paste,collapse="_")


extract_data<-function(fn, mkrs,minN) {
  datas<-read.table(fn,header=TRUE,sep="\t",colClass=c("character",rep("integer",6)))
  nnn<-grep("GL",datas[,1],value=TRUE)
  datas<-datas[!(datas[,1] %in% nnn),]
  colnames(datas)<-c("Chr","Pos","A","C","G","T","N")
  tmp<-matrix(unlist(strsplit(datas[,1],split=".",fixed=TRUE)),ncol=2,byrow=TRUE)
  datas[,1]<-tmp[,1]
  needs<-rep(FALSE,nrow(datas)) 
  for(i in 1:nrow(mkrs)) {
    tmp<-which(as.character(datas[,1])==as.character(mkrs[i,1]) & abs(datas[,2]-mkrs[i,2])<1000 & as.numeric(datas[,"N"])>minN)
	needs[tmp]<-TRUE
  }
  rlt<-datas[needs,]
  row.names(rlt)<-apply(cbind(as.character(rlt[,1]),as.character(rlt[,2])),1,paste,collapse="_")
  return(rlt)
}

extract_data_v2<-function(fn, sites) {
  datas<-read.table(fn,header=TRUE,sep="\t",colClass=c("character",rep("integer",6)))
  nnn<-grep("GL",datas[,1],value=TRUE)
  datas<-datas[!(datas[,1] %in% nnn),]
  colnames(datas)<-c("Chr","Pos","A","C","G","T","N")
  tmp<-matrix(unlist(strsplit(datas[,1],split=".",fixed=TRUE)),ncol=2,byrow=TRUE)
  datas[,1]<-tmp[,1]
  row.names(datas)<-apply(cbind(as.character(datas[,1]),as.character(datas[,2])),1,paste,collapse="_")
  rlt<-datas[sites,]
  return(rlt)
}

join_data<-function(da,db,a_tag,b_tag) {
  row.names(da)<-apply(cbind(as.character(da[,1]),as.character(da[,2])),1,paste,collapse=".")
  row.names(db)<-apply(cbind(as.character(db[,1]),as.character(db[,2])),1,paste,collapse=".")
  common<-intersect(row.names(da),row.names(db))
  da<-da[common,]
  db<-db[common,]
  colnames(da)[3:7]<-paste(a_tag,colnames(da)[3:7],sep="")
  colnames(db)<-paste(b_tag,colnames(db),sep="")
  rlt<-cbind(da[,1:7],db[,3:8])
  return(rlt) 
}

obtain_sites<-function(markerset) {
  minN<-500000
  fns<-dir(path=".",pattern="count_4Fig3b")
  use<-NULL
  for(i in 1:length(fns)) {
    tmp<-extract_data(fns[i],mkrs=mkr,minN=minN)
    use<-union(use,row.names(tmp))  
    print(i)
  }
  use<-setdiff(use,markerset)
  return(use)
}


genotype<-function(fn,sites) {
  d1<-extract_data_v2(fn, sites)
  A<-d1[,"A"]
  C<-d1[,"C"]
  G<-d1[,"G"]
  T<-d1[,"T"]
  N<-d1[,"N"]
  rlt<-cbind(d1[,1:2],A,C,G,T,N)
  geno<-rep("",nrow(rlt))
  geno[A>0.9*N]<-"A"
  geno[C>0.9*N]<-"C"
  geno[G>0.9*N]<-"G"
  geno[T>0.9*N]<-"T"
  rlt<-cbind(rlt,geno)
  return(rlt)  
}



do_one_comp<-function(ha,sj,minN,main) {
  epsilon<-1/10000000
  common<-intersect(row.names(ha)[ha[,"N"]>minN],row.names(sj)[sj[,"N"]>minN])
  ha<-ha[common,]
  sj<-sj[common,]
  letterss<-c("A","C","G","T")
  kk<-NULL
  nms<-NULL
  
  medians<-NULL
  PP<-NULL
  for(ref in 1:length(letterss)) {
    for(mut in 1:length(letterss)) {
	  if(mut != ref) {
	    needss<-as.character(ha[,"geno"])==letterss[ref]
	    val.ha<-log10(ha[needss,letterss[mut]]/ha[needss,"N"]+epsilon)
	    val.sj<-log10(sj[needss,letterss[mut]]/sj[needss,"N"]+epsilon)
	    kk<-cbind(kk,c(val.sj,rep(NA,800-length(val.sj))),c(val.ha,rep(NA,800-length(val.ha))))
	    nms<-c(nms,paste(c(letterss[ref],">",letterss[mut],";SJ (",length(val.sj),")"),collapse=""),paste(c(letterss[ref],">",letterss[mut],";HA (",length(val.ha),")"),collapse=""))
		medians<-c(medians,median(val.sj),median(val.ha))
		P<-wilcox.test(val.ha,val.sj,alternative="less")$p.value
		print(paste(c(letterss[ref],">",letterss[mut], " P:",P),collapse=""))
		PP<-c(PP,P)
	  }
	}
  }
  colnames(kk)<-nms
  library(beeswarm)
  beeswarm((as.data.frame(kk)),horiz=TRUE,las=1,cex=0.2,col=c("tomato","skyblue"),pch=16,cex.axis=0.5,main=main, xlab = 'Overall Error Rate (log10)')
  for(i in 1:ncol(kk)) {
    lines(c(medians[i],medians[i]),c(i-0.3,i+0.3),lwd=2,col="black")
	text(-7,i,sprintf("%.1f",medians[i]),cex=0.6)
  }
  for(i in 1:length(PP)) {
    text(-3,i*2-0.5,sprintf("%.0e",PP[i]),cex=0.6)
  }  
}


markerset<-c(row.names(mkr),"1_153391729","1_153391786")
sites<-obtain_sites(markerset)

fn1<-"count_4Fig3b_HAIB"
fn2<-"count_4Fig3b_SJ"
haib<-genotype(fn1,sites)
sj<-genotype(fn2,sites)


minN<-2000000

pdf("Fig3b.pdf",useDingbats=FALSE,width=7,height=8)
do_one_comp(ha=haib,sj,minN,main="comparison HAIB&SJ")

dev.off()

