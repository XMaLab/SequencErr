
med_sj<-median(read.table("error_rate.A00214_H37LCDRXX.txt",header=TRUE,sep="\t")[,"ERPM"])
med_ha<-median(read.table("error_rate.A00363_H3CMMDRXX.txt",header=TRUE,sep="\t")[,"ERPM"])


sj<-log10(read.table("error_rate.A00214_H37LCDRXX.txt",header=TRUE,sep="\t")[,"ERPM"]+0.001)
ha<-log10(read.table("error_rate.A00363_H3CMMDRXX.txt",header=TRUE,sep="\t")[,"ERPM"]+0.001)

pdf("Fig3a.pdf",useDingbats=FALSE,width=10,height=5)

dataa<-list(HAIB=ha,SJ=sj)
names(dataa)<-c(paste(c("HAIB (n=",length(ha),")"),collapse=""),paste(c("SJ (n=",length(sj),")"),collapse=""))
library(beeswarm)
beeswarm(dataa,horiz=TRUE,las=1,cex=0.4,col=c("skyblue","tomato"),cex.axis=0.5,xaxt="n")
axis(1,at=c(-1,0,1,2,3),labels=c(0.1,1,10,100,1000))
lines(c(log10(0.001+med_sj),log10(0.001+med_sj)),c(2-0.3,2+0.3),lwd=1)
lines(c(log10(0.001+med_ha),log10(0.001+med_ha)),c(1-0.3,1+0.3),lwd=1)
text(3,1,med_ha,cex=0.5)
text(3,2,med_sj,cex=0.5)
lines(c(log10(100+0.001),log10(100+0.001)),c(0,3),lty=2)


dev.off()



