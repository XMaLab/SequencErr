
library(beeswarm)
hist_surface<-function(ifn,main) {
  dt<-read.table(ifn,header=TRUE,sep="\t",row.names=1)  
  top<-log10(dt[grep("_1",row.names(dt),value=TRUE),3]+0.01)
  bot<-log10(dt[grep("_2",row.names(dt),value=TRUE),3]+0.01)
  ret<-list(Top=top,Bottom=bot)
  med_top<-median(dt[grep("_1",row.names(dt),value=TRUE),3])
  med_bot<-median(dt[grep("_2",row.names(dt),value=TRUE),3])
  beeswarm(ret,main=main,cex=0.3,col=c("skyblue","tomato"),yaxt="n",ylim=c(-1.2,3.5),ylab="Tile-level error rate(per million)")
  axis(2,at=c(-1,0,1,2,3),labels=c(0.1,1,10,100,1000))
  lines(c(0.7,1.3),c(log10(med_top+0.01),log10(med_top+0.01)))
  text(1,log10(med_top+0.01)+0.3,med_top)
  lines(c(1.7,2.3),c(log10(med_bot+0.01),log10(med_bot+0.01)))
  text(2,log10(med_bot+0.01)+0.3,med_bot)
}

pdf("FigS6ab_surface.pdf",useDingbats=FALSE,width=8,height=6)
par(mfrow=c(1,2))
ifn<-"error_rate.A00363_H3CMMDRXX.txt"
hist_surface(ifn,main="HAIB (A00363)")
ifn<-"error_rate.A00214_H37LCDRXX.txt"
hist_surface(ifn,main="SJ (A00214)")
dev.off()

