
obtain_lm<-function(lm.D) {
  b<-sprintf("%.2f",as.numeric(summary(lm.D)$coeff[2,1]))
  a<-sprintf("%.2f",as.numeric(summary(lm.D)$coeff[1,1]))
  r2<-sprintf("%.2f",summary(lm.D)$adj.r.sq)
  ret<-paste(c("y=",a,"+",b,"x; adj.r2=",r2),collapse="")
  return(ret)
}


make_summary<-function(ifn) {
  dt<-read.table(ifn,header=TRUE,sep="\t",check.names=F)
  row.names(dt)<-apply(cbind(as.character(dt[,3]),as.character(dt[,4])),1,paste,collapse="_")
  nms<-matrix(unlist(strsplit(grep(">",colnames(dt),value=TRUE),split="")),ncol=3,byrow=TRUE)
  row.names(nms)<-apply(nms,1,paste,collapse="")
  use.all<-row.names(nms)
  use.mismatch<-row.names(nms)[nms[,1]!=nms[,3]]

  Tot<-apply(dt[,use.all],1,sum)
  Err<-apply(dt[,use.mismatch],1,sum)
  Err.Rate<-1000000*Err/Tot

  Outlier<-row.names(dt)[Err.Rate>100]
  Top<-setdiff(grep("_1",row.names(dt),value=TRUE),Outlier)
  Bot<-setdiff(grep("_2",row.names(dt),value=TRUE),Outlier)

  cnts.Top<-apply(dt[Top,use.all]+0.0000000000001,2,sum)
  cnts.Bot<-apply(dt[Bot,use.all]+0.0000000000001,2,sum)
  cnts.Outlier<-apply(dt[Outlier,use.all]+0.0000000000001,2,sum)

  rlt<-rbind(cnts.Top,cnts.Bot,cnts.Outlier)
  return(rlt)
}

ifn<-"nofilter/pairError.3a_HAIB"
haib<-make_summary(ifn)

ifn<-"nofilter/pairError.3a_SJ"
sj<-make_summary(ifn)

kk<-rbind(cbind(haib,"HAIB"),cbind(sj,"SJ"))
colnames(kk)<-c(colnames(haib),"Center")
write.table(kk,"ErrorType.txt",row.names=F,col.names=TRUE,sep="\t",quote=F)

dt<-read.table("ErrorType.txt",header=TRUE,sep="\t",check.names=F)

nms<-matrix(unlist(strsplit(grep(">",colnames(dt),value=TRUE),split="")),ncol=3,byrow=TRUE)
row.names(nms)<-apply(nms,1,paste,collapse="")
use.all<-row.names(nms)
use.mismatch<-row.names(nms)[nms[,1]!=nms[,3]]
totals<-apply(dt[,use.all],1,sum)

err.rate<-dt[,use.mismatch]
for(i in 1:nrow(err.rate)) {
  err.rate[i,]<-1000000*err.rate[i,]/totals[i]
}

haib.err.rate<-err.rate[1:3,]
row.names(haib.err.rate)<-c("Top","Bottom","Outlier")
haib.overall<-c(1.2,50.1,7.9,7.9,3.2,31.6,31.6,4,7.9,7.9,50.1,1.2)
names(haib.overall)<-colnames(haib.err.rate)
sj.err.rate<-err.rate[4:6,]
row.names(sj.err.rate)<-c("Top","Bottom","Outlier")
sj.overall<-c(7.9,79.4,20,12.6,12.6,39.8,39.8,12.6,10,20,79.4,7.9)
names(sj.overall)<-colnames(sj.err.rate)

haib.err.rate<-rbind(haib.err.rate,overall=haib.overall)
sj.err.rate<-rbind(sj.err.rate,overall=sj.overall)

pdf("FigS6c.pdf",width=12,height=6,useDingbats=FALSE)
par(mfrow=c(1,2))
  pchs<-rep(1,ncol(haib.err.rate))
  pchs[colnames(haib.err.rate) %in% c("A>C","T>G")]<-1
  pchs[colnames(haib.err.rate) %in% c("A>G","T>C")]<-2
  pchs[colnames(haib.err.rate) %in% c("A>T","T>A")]<-3
  pchs[colnames(haib.err.rate) %in% c("C>A","G>T")]<-4
  pchs[colnames(haib.err.rate) %in% c("C>G","G>C")]<-5
  pchs[colnames(haib.err.rate) %in% c("C>T","G>A")]<-6
  val<-(t(haib.err.rate["Top",]))
  overall<-(t(haib.err.rate[4,]))  
  plot(overall,val,xlim=c(0.5,100),ylim=c(0.00001,1000),col="skyblue",pch=pchs,cex=2,lwd=2,log="xy",main="HAIB (A00363)",xlab="Overall error rate (per million)",ylab="Seqencer error rate (per million)")
  lm.top<-lm(log10(val)~log10(overall))
  #print(summary(lm.top))
  abline(lm.top,col="skyblue",lwd=2)
  rlt.top<-obtain_lm(lm.top)
  text(3,0.001,rlt.top,col="skyblue",pos=4)
  val<-(t(haib.err.rate["Bottom",]))
  points(overall,val,col="orange",pch=pchs,cex=2,lwd=2)
  lm.bot<-lm(log10(val)~log10(overall))
  #print(summary(lm.bot))
  abline(lm.bot,col="orange",lwd=2)
  rlt.bot<-obtain_lm(lm.bot)
  text(3,0.0001,rlt.bot,col="orange",pos=4)
  val<-(t(haib.err.rate["Outlier",]))  
  val[val<0.00005]<-0.00005
  points(overall,val,col="black",pch=pchs,cex=2,lwd=2)
  legend("bottomleft", pch=1:6,legend=c("A>C/T>G","A>G/T>C","A>T/T>A","C>A/G>T","C>G/G>C","C>T/G>A"))
  legend("topright",lwd=2,col=c("skyblue","orange","black"),legend=c("Top","Bottom","Outlier"))
  
 
  pchs<-rep(1,ncol(sj.err.rate))
  pchs[colnames(sj.err.rate) %in% c("A>C","T>G")]<-1
  pchs[colnames(sj.err.rate) %in% c("A>G","T>C")]<-2
  pchs[colnames(sj.err.rate) %in% c("A>T","T>A")]<-3
  pchs[colnames(sj.err.rate) %in% c("C>A","G>T")]<-4
  pchs[colnames(sj.err.rate) %in% c("C>G","G>C")]<-5
  pchs[colnames(sj.err.rate) %in% c("C>T","G>A")]<-6
  val<-(t(sj.err.rate["Top",]))
  overall<-(t(sj.err.rate[4,]))  
  plot(overall,val,xlim=c(5,100),ylim=c(0.00001,200),col="skyblue",pch=pchs,cex=2,lwd=2,log="xy",main="SJ (A00214)",xlab="Overall error rate (per million)",ylab="Seqencer error rate (per million)")
  lm.top<-lm(log10(val)~log10(overall))
  #print(summary(lm.top))
  abline(lm.top,col="skyblue",lwd=2)
  rlt.top<-obtain_lm(lm.top)
  text(15,0.001,rlt.top,col="skyblue",pos=4)
  val<-(t(sj.err.rate["Bottom",]))
  points(overall,val,col="orange",pch=pchs,cex=2,lwd=2)
  lm.bot<-lm(log10(val)~log10(overall))
  #print(summary(lm.bot))
  abline(lm.bot,col="orange",lwd=2)
  rlt.bot<-obtain_lm(lm.bot)
  text(15,0.0001,rlt.bot,col="orange",pos=4)
  val<-(t(sj.err.rate["Outlier",]))  
  val[val<0.00005]<-0.00005
  points(overall,val,col="black",pch=pchs,cex=2,lwd=2)
  legend("bottomleft", pch=1:6,legend=c("A>C/T>G","A>G/T>C","A>T/T>A","C>A/G>T","C>G/G>C","C>T/G>A"))
  legend("topright",lwd=2,col=c("skyblue","orange","black"),legend=c("Top","Bottom","Outlier"))
dev.off()
