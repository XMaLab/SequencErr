import sys
import os
data={}

def count_error_rate(inputfile):
	fh=open(inputfile,"r")
	header_lst=fh.readline().strip().split("\t")
	for line in fh.readlines():
		lst=line.strip().split("\t")
		instrument=lst[0]
		flow_cell=lst[1]
		instrument_flowcell=instrument+"_"+flow_cell
		tile=lst[2]+"_"+lst[3]
		tmp_data=dict(zip(header_lst[4:],lst[4:]))
		total=0
		Match=0
		Error=0
		for i in tmp_data:
			total+=int(tmp_data[i])
			if i[0]==i[2]:
				Match+=int(tmp_data[i])
			else:
				Error+=int(tmp_data[i])
		#ERPM=round(float(1000000*Error)/(2*total),4)
		if total>0:
			ERPM=round(float(1000000*Error)/(total+0.00001),4)
		if instrument_flowcell not in data:
			data[instrument_flowcell]={}
		if tile not in data[instrument_flowcell]:
			data[instrument_flowcell][tile]={}
		data[instrument_flowcell][tile]={
			"Macth":Match,
			"Error":Error,
			"ERPM":ERPM
		}
	fh.close()

count_error_rate("./nofilter/pairError.4a_HAIB")
count_error_rate("./nofilter/pairError.4a_SJ")
for instrument_flowcell in data:
	out_file="error_rate."+instrument_flowcell+".txt"
	with open (out_file,"w") as out_fh:
		out_fh.write("Tile\tMatch\tError\tERPM\n")
		for tile in data[instrument_flowcell]:
			content=tile+"\t"+str(data[instrument_flowcell][tile]["Macth"])+"\t"+str(data[instrument_flowcell][tile]["Error"])+"\t"+str(data[instrument_flowcell][tile]["ERPM"])
			out_fh.write(content+"\n")
	


		




