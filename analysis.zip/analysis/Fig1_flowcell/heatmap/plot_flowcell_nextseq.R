
generate_tile_info_nextseq<-function() {
  nLane<-4
  nSurface<-2
  nSwath<-3
  nCamera<-3
  nTile<-12
  Surface<-c(rep(1,nLane*nSwath),rep(2,nLane*nSwath))
  Lane<-c(rep(1,nSwath),rep(2,nSwath),rep(3,nSwath),rep(4,nSwath),rep(1,nSwath),rep(2,nSwath),rep(3,nSwath),rep(4,nSwath))
  Swath<-rep(1:nSwath,nLane*nSurface)
  Row_Info<-cbind(Swath,Lane,Surface)
  Camera<-c(rep(1,nTile),rep(2,nTile),rep(3,nTile)) 
  Tile<-rep(1:12,nCamera)
  Col_Info<-cbind(Tile,Camera)  
  TileID<-matrix("",nrow=nSurface*nLane*nSwath,ncol=nCamera*nTile)  
  TileValue<-matrix(-1000,nrow=nSurface*nLane*nSwath,ncol=nCamera*nTile)
  for(i in 1:nrow(Row_Info)) {
    for(j in 1:nrow(Col_Info)) {
	  theid<-Row_Info[i,"Surface"]*10000+Row_Info[i,"Swath"]*1000+Col_Info[j,"Camera"]*100+Col_Info[j,"Tile"]
	  TileID[i,j]<-paste(c(Row_Info[i,"Lane"],"_",theid),collapse="")	  
	}
  }
  row.names(TileID)<-apply(Row_Info,1,paste,collapse="_")
  colnames(TileID)<-apply(Col_Info,1,paste,collapse="_")
  row.names(TileValue)<-apply(Row_Info,1,paste,collapse="_")
  colnames(TileValue)<-apply(Col_Info,1,paste,collapse="_")
  row.names(Row_Info)<-apply(Row_Info,1,paste,collapse="_")
  row.names(Col_Info)<-apply(Col_Info,1,paste,collapse="_")  
  Row_Info[,1]<-paste("W",Row_Info[,1],sep="")
  Row_Info[,2]<-paste("L",Row_Info[,2],sep="")
  Row_Info[,3]<-paste("S",Row_Info[,3],sep="")
  rlt<-list(TileID=TileID,TileValue=TileValue,Col_Info=Col_Info,Row_Info=Row_Info)
  return(rlt)
}


library(pheatmap)
library(RColorBrewer)
#if (!require("devtools")) {
#  install.packages("devtools", dependencies = TRUE)
#  library(devtools)
#}
#install_github("raivokolde/pheatmap")


do_nextseq<-function() {
  errorCeiling<-200
  breaksList <- seq(0, (errorCeiling+10), by = 1)
  dt<-read.table("nextseq_error_rates_all.txt",header=TRUE,sep="\t",row.names=1)  
  infoo<-matrix(unlist(strsplit(row.names(dt),split="")),ncol=7,byrow=TRUE)
  Lane<-as.integer(infoo[,1])
  Surface<-as.integer(infoo[,3])
  Swath<-as.integer(infoo[,4])
  Camera<-as.integer(infoo[,5])
  Camera[Camera==6]<-1
  Camera[Camera==5]<-2
  Camera[Camera==4]<-3
  Tile<-as.integer(apply(infoo[,6:7],1,paste,collapse=""))
  idsss<-Surface*10000+Swath*1000+Camera*100+Tile
  newinfo<-apply(cbind(Lane,"_",idsss),1,paste,collapse="")
  row.names(dt)<-newinfo
  
  pdf("NextSeq_heatmap.pdf",width=15,height=8)
  for(i in 1:ncol(dt)) {
    print(i)
    sampless<-colnames(dt)[i]
	ctrls<-generate_tile_info_nextseq()
	for(j in 1:nrow(ctrls$TileID)) {
	  for(k in 1:ncol(ctrls$TileID)) {
	    if(ctrls$TileID[j,k] %in% newinfo) {
		  ctrls$TileValue[j,k]<-dt[ctrls$TileID[j,k],sampless]
		  if(!is.na(ctrls$TileValue[j,k])) {
		    if(ctrls$TileValue[j,k]>errorCeiling) {
		      ctrls$TileValue[j,k]<-errorCeiling-2
			}
		  }
		  if(!is.na(ctrls$TileValue[j,k])) {
		    if(ctrls$TileValue[j,k]>=0.00001) {
			  ctrls$TileValue[j,k]<-(ctrls$TileValue[j,k]+0.01)
			}
		  }
		}
	  }
	}
	anno_row<-data.frame(ctrls$Row_Info)
	anno_col<-data.frame(ctrls$Col_Info)
	colors_anno<-list(Surface=c(S1="skyblue",S2="tomato"),
	                  Lane=c(L1="#CCCCCC",L2="#BBBBBB",L3="#AAAAAA",L4="#999999",L5="#888888",L6="#777777",L7="#666666",L8="#555555"),
					  Swath=c(W1="#00EE00",W2="#00AA00",W3="#006600",W4="#004400",W5="#002200",W6="#001100"))
	pheatmap(ctrls$TileValue,cluster_rows = FALSE, cluster_cols = FALSE,na_col="#000000",border_color="white",lwd=0.5,
	         breaks = breaksList,annotation_colors=colors_anno,
	         color = colorRampPalette(rev(brewer.pal(n = 7, name = "RdYlBu")))(length(breaksList)),			 
	         annotation_row =anno_row,annotation_col =anno_col,
	         gaps_row  = c(3,6,6,6,9,12,12,12,12,12,12,15,18,18,18,21,24), gaps_col = c(12,12,12,12,12,24,24,24,12,12,36,36,36,36,36),main=sampless)
  }  
  dev.off()
}

do_nextseq()

